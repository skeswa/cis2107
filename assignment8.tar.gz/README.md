#Sandile Keswa's Assignment 8
##File Descriptions
 - spellcheck.c - The spellchecker program
 - FILE - The sample file to spellcheck
 - DICT - The sample dictionary
##How to Use
The commands are as follows:  
    
    gcc -o spellcheck spellcheck.c
    ./spellcheck <FILEPATH_PATH> <DICTIONARY_PATH>

A sample execution would look like:

    ./spellcheck FILE DICT

##Explanation
Sorry this assignment was a bit late, I've had a really busy week at work.
##Contact
Email: sandile.keswa@gmail.com  
Phone: 267-560-7263